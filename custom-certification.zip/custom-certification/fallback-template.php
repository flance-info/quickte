<div class="fallback-certificate">In order to emit certificate</div>
<div class="fallback-certificate">Please add this student's email to customer list in his/her order.</div>
<div class="fallback-images">
    <img style="text-align: center"
         src="<?php echo get_stylesheet_directory_uri(); ?>/custom-certification/img/fallback-image.webp" alt="">
</div>
<style>
    .fallback-certificate {
        text-align: center;
        font-size: 30px;
        font-weight: bold;
    }

    .fallback-images {
        display: grid;
        place-content: center;
        margin-top: 30px;
    }
</style>