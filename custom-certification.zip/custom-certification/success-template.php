<?php if ($order_id): ?>
    <h1 class="success-certificate">
        <?php esc_html_e('Click button below in order to emit certificate', 'masterstudy-lms-learning-management-system') ?>
    </h1>
    <h3 style="color: #457992" class="success-certificate">
        <?php echo wp_kses_post(get_the_title($course['course_id'])); ?>
    </h3>

    <div class="button-download">
        <button
                class="get-certificate"
                data-id="<?= esc_attr($course['user_course_id']) ?>"
                data-course_id="<?= esc_attr($course['course_id']) ?>"
                fiscal-code="<?= esc_attr($results[0]->meta_value) ?>"
                data-student-name="<?= esc_attr($results[1]->meta_value) ?>"
                certificate-code="<?= esc_attr($user_certificate_code) ?>"
                nonce="<?= esc_attr($nonce) ?>"
                started="<?= esc_attr($course['start_time']) ?>"
                style="padding: 10px 20px;
                cursor: pointer;
                width: 200px;
                background-color: #000;
                color: #fff;
                text-decoration: none;
                border-radius: 30px;
                ">
            <?php esc_html_e('Download', 'masterstudy-lms-learning-management-system'); ?>
        </button>
    </div>
    <hr>
<?php else: ?>
    <h3 style="color: orangered" class="success-certificate">
        <?php echo wp_kses_post(get_the_title($course['course_id'])); ?>
    </h3>

    <h4 class="failed-certificate"><?php esc_html_e('Student does not have a certificate yet for this course.', 'masterstudy-lms-learning-management-system'); ?></h4>
    <h4 class="failed-certificate"><?php esc_html_e('Please register credentials in woocomerce orders, and make sure order is completed to get certificate', 'masterstudy-lms-learning-management-system'); ?></h4>
<?php endif ?>
<style>
    .success-certificate {
        text-align: center;
        font-size: 30px;
        font-weight: bold;
        margin-top: 30px;
    }

    .failed-certificate {
        text-align: center;
        font-size: 22px;
        font-weight: bold;
        margin-top: 30px;
    }

    .button-download {
        display: grid;
        place-content: center;
        margin-top: 30px;
    }
</style>